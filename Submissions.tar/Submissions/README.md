
In this Assignment, I learned how to give permission to specific user with the command "setfacl -m u:username:permission file name."
Also, learned how to copy a file from another directory to my directory. 
When the name of the file has space between word like "The Hunger Game", you must set the path with \ key like The\ Hunger\ Game.
If you want to replace every occurence of one character name with your own, use :%s/replacedWord/preferWord/g command.
I changed all I in the Hunger Game file to CheonggangSim which is my name.
"mv oldfilename newfile" change the file names. 
# systemLevel
